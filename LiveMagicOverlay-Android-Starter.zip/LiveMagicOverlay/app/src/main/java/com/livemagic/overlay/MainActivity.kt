package com.livemagic.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val overlayRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF10151F.toInt())
        }
        root.addView(TextView(this).apply {
            text = "LIVE MAGIC OVERLAY"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Draggable profile card • Viewer join crate • Gift effects\n\nBackend: http://127.0.0.1:3000\nStart your Termux backend before testing."
            textSize = 16f
            setTextColor(0xFFD7E1F2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "ENABLE FLOATING OVERLAY"
            setOnClickListener { enableOverlay() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(Button(this).apply {
            text = "STOP OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4103)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), overlayRequest)
        } else startOverlay()
    }

    private fun startOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Floating overlay started", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Deprecated permission callback retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest) {
            if (Settings.canDrawOverlays(this)) startOverlay()
            else Toast.makeText(this, "Allow Display over other apps", Toast.LENGTH_LONG).show()
        }
    }
}
