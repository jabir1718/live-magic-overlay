package com.livemagic.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import io.socket.client.IO
import io.socket.client.Socket
import java.net.URL
import java.util.concurrent.Executors

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var card: LinearLayout? = null
    private var popup: TextView? = null
    private var socket: Socket? = null
    private lateinit var avatar: ImageView
    private lateinit var username: TextView
    private lateinit var status: TextView
    private lateinit var eventLine: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        startForeground(77, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        makeCard()
        connect()
    }

    private fun notification(): Notification {
        val id = "live_magic_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(id, "LIVE Magic Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val n = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, id) else Notification.Builder(this)
        return n.setContentTitle("LIVE Magic Overlay").setContentText("Floating overlay is running")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }

    private fun round(bg: Int, stroke: Int = 0xFF8795A8.toInt(), radius: Float = 22f) =
        GradientDrawable().apply { setColor(bg); cornerRadius = radius; setStroke(2, stroke) }

    private fun makeCard() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            background = round(0xF8FFFFFF.toInt())
            elevation = 12f
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        avatar = ImageView(this).apply {
            setImageResource(android.R.drawable.sym_def_app_icon)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = round(0xFFE4EAF2.toInt(), radius = 60f)
            clipToOutline = true
        }
        row.addView(avatar, LinearLayout.LayoutParams(54, 54))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(10, 0, 6, 0) }
        username = TextView(this).apply { text = "LIVE Magic Overlay"; textSize = 15f; setTextColor(Color.BLACK); typeface = Typeface.DEFAULT_BOLD; maxLines = 1 }
        status = TextView(this).apply { text = "Connecting…"; textSize = 11f; setTextColor(0xFF526176.toInt()) }
        col.addView(username); col.addView(status)
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = "×"; textSize = 25f; setTextColor(0xFF3D4655.toInt()); setPadding(6, 0, 2, 0)
            setOnClickListener { stopSelf() }
        })
        box.addView(row)
        eventLine = TextView(this).apply { text = "Waiting for LIVE joins and gifts"; textSize = 12f; setTextColor(0xFF465365.toInt()); setPadding(2, 8, 2, 0) }
        box.addView(eventLine)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 18; y = 180 }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> { p.x = sx + (e.rawX - tx).toInt(); p.y = sy + (e.rawY - ty).toInt(); try { wm.updateViewLayout(box, p) } catch (_: Exception) {}; true }
                else -> false
            }
        }
        card = box
        wm.addView(box, p)
    }

    private fun connect() {
        try {
            val opts = IO.Options.builder().setReconnection(true).setReconnectionDelay(1500).build()
            socket = IO.socket("http://127.0.0.1:3000", opts)
            socket?.on(Socket.EVENT_CONNECT) { handler.post { status.text = "Connected • listening" } }
            socket?.on(Socket.EVENT_CONNECT_ERROR) { handler.post { status.text = "Backend not connected" } }
            socket?.on(Socket.EVENT_DISCONNECT) { handler.post { status.text = "Disconnected • reconnecting" } }
            socket?.on("live-event") { args ->
                val raw = args.firstOrNull()?.toString() ?: return@on
                handler.post { handleEvent(raw) }
            }
            socket?.connect()
        } catch (_: Exception) { status.text = "Connection error" }
    }

    private fun handleEvent(raw: String) {
        try {
            val j = JSONObject(raw)
            val type = j.optString("type", j.optString("event", ""))
            val user = j.optJSONObject("user") ?: JSONObject()
            val name = user.optString("nickname", user.optString("uniqueId", "LIVE viewer"))
            val image = user.optString("avatarUrl", user.optString("avatar_url", ""))
            username.text = name
            when {
                type.contains("member", true) || type.contains("join", true) -> {
                    eventLine.text = "Viewer joined"
                    status.text = "New viewer"
                    loadAvatar(image)
                    showPopup("📦 SUPPLY DROP", name, 2600)
                }
                type.contains("gift", true) -> {
                    val g = j.optJSONObject("gift") ?: JSONObject()
                    val giftName = g.optString("name", "Gift")
                    val diamonds = g.optInt("diamondCount", g.optInt("diamond_count", 1))
                    val count = g.optInt("repeatCount", g.optInt("count", 1)).coerceAtLeast(1)
                    val total = diamonds * count
                    eventLine.text = "🎁 $giftName ×$count • $total diamonds"
                    val tier = when { total >= 1000 -> "👑 LEGENDARY DROP"; total >= 100 -> "🔥 EPIC DROP"; total >= 10 -> "✨ RARE DROP"; else -> "🎁 GIFT DROP" }
                    status.text = tier
                    loadAvatar(image)
                    showPopup(tier, "$name • $giftName ×$count", 3000)
                }
                else -> eventLine.text = "LIVE event: $type"
            }
        } catch (_: Exception) { eventLine.text = "Received LIVE event" }
    }

    private fun showPopup(title: String, subtitle: String, delay: Long) {
        val v = TextView(this).apply {
            text = "$title\n$subtitle"; textSize = 17f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(18, 18, 18, 18)
            background = round(0xEE18243A.toInt(), 0xFFFFC857.toInt(), 18f); elevation = 20f
        }
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try {
            popup?.let { wm.removeView(it) }
            popup = v
            wm.addView(v, p)
            v.scaleX = 0.25f; v.scaleY = 0.25f; v.alpha = 0f
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(350).withEndAction {
                v.animate().rotationBy(4f).setDuration(140).withEndAction {
                    v.animate().rotationBy(-8f).setDuration(140).withEndAction { v.animate().rotationBy(4f).setDuration(140).start() }.start()
                }.start()
            }.start()
            handler.postDelayed({
                v.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(250).withEndAction {
                    try { wm.removeView(v) } catch (_: Exception) {}
                    if (popup === v) popup = null
                }.start()
            }, delay)
        } catch (_: Exception) {}
    }

    private fun loadAvatar(url: String) {
        if (url.isBlank()) return
        worker.execute {
            try {
                val bmp = URL(url).openStream().use { BitmapFactory.decodeStream(it) }
                if (bmp != null) handler.post { avatar.setImageBitmap(bmp) }
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        try { socket?.disconnect(); socket?.close() } catch (_: Exception) {}
        try { popup?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { card?.let { wm.removeView(it) } } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
