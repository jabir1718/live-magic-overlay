# LIVE Magic Overlay — Android starter

This is an initial Android Studio project scaffold for a draggable floating card and viewer/gift popups.

## Requirements
- Android Studio, JDK 17, Android SDK 35
- Existing Termux backend running on the same phone at `http://127.0.0.1:3000`
- Backend emits Socket.IO event `live-event`

## Build
Open the `LiveMagicOverlay` folder in Android Studio, sync Gradle, then use **Build > Build APK(s)**.

## First run
1. Start the Termux backend.
2. Install and open the APK.
3. Tap **ENABLE FLOATING OVERLAY** and allow Display over other apps.
4. Drag the white card to move it. Tap × on the card to stop the overlay.
5. Check backend event names/JSON if events do not appear.

This is a starter build and has not been compiled/tested on your phone yet.
